# CSCI335-Assignment2

i. which part complated
all of Part 1 and Part 2

ii. bugs

iii. How to run this program
    $ make all

    For Part 2a, 
    $ ./query_tree rebase210.txt <Tree Flag> < <Input file>

    For example,
    $ .query_tree rebase210.txt AVL < input_part2a.txt


    For Part 2b,
    $ ./test_tree rebase210.txt sequences.txt <Tree Flag>

    for example,
    $ ./test_tree rebase210.txt sequences.txt BST

iv. input and output files
    inputs: rebase210.txt(database), input_part2a.txt(part2a input), sequence.txt(query sequence)